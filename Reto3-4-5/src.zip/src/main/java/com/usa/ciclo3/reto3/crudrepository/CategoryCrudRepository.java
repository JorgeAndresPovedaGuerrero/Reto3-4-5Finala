package com.usa.ciclo3.reto3.crudrepository;

import com.usa.ciclo3.reto3.model.Category;
import org.springframework.data.repository.CrudRepository;

public interface CategoryCrudRepository extends CrudRepository<Category, Integer> {
}
