package com.usa.ciclo3.reto3.crudrepository;

import com.usa.ciclo3.reto3.model.Client;
import org.springframework.data.repository.CrudRepository;

public interface ClientCrudRepository extends CrudRepository<Client, Integer>  {
}
