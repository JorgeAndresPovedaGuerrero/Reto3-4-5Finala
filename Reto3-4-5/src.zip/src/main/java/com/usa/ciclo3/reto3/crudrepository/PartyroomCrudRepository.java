package com.usa.ciclo3.reto3.crudrepository;

import com.usa.ciclo3.reto3.model.Partyroom;
import org.springframework.data.repository.CrudRepository;

public interface PartyroomCrudRepository extends CrudRepository<Partyroom, Integer> {
}
